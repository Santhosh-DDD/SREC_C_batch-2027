#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node *next;
};
struct Node *front=NULL , *rear=NULL;
void enqueue(int val)
{
    struct Node *newnode = (struct Node*)malloc(sizeof(struct Node *));
    if(newnode==NULL)
        printf("No memory");
    else{
        if(front==NULL)
        {
            newnode ->data = val;
            newnode ->next =NULL;
            front=newnode;
            rear = newnode;
        }
        else{
            newnode->data = val;
            newnode->next = NULL;
            rear -> next = newnode;
            rear = newnode;
        }
    }
}
void display()
{
    if(front==NULL)
        printf("Queue is empty");
    else
    {
        struct Node *temp = front;
        while(temp!=NULL)
        {
            printf("%d ->",temp->data);
            temp = temp ->next;
        }
    }
}
void dequeue()
{
    if(front==NULL)
        printf("underflow");
    else
    {
        struct Node *temp = front;
        if(front==rear)
        {
            front=NULL;
            rear = NULL;
            free(temp);
        }
        else{
            front = front ->next;
            free(temp);
        }
    }
}
int front_element()
{
    if(front==NULL)
        return -1;
    else
        return front->data;
}
int rear_element()
{
    if(front==NULL)
        return -1;
    else
       return rear->data;
}
int length()
{
    if(front==NULL)
        return 0;
    else{
        if(front==rear)
            return 1;

        struct Node *temp = front;
        int count=0;
        while(temp!=NULL)
        {
            count++;
            temp = temp->next;
        }
        return count;
    }

}
int main()
{
    printf("1.enqueue 2.dequeue 3.display 4.front 5.rear -1.exit\n");
    int choice;
    while(1)
    {
        scanf("%d",&choice);
        if(choice==-1)
            break;
        else{
            switch(choice)
            {
                case 1:{  int ele;
                        scanf("%d",&ele);
                        enqueue(ele);
                }break;
                case 2:dequeue();break;
                case 3:display();break;
                case 4:{
                       int f = front_element();
                       if(f==-1)
                        printf("No front element\n");
                       else
                          printf("Front element is %d\n",f);
                }break;
                case 5:{
                       int r = rear_element();
                       if(r==-1)
                          printf("No rear element");
                       else
                          printf("Rear element is %d\n",r);
                }break;
                case 6:{
                      int len = length();
                      printf("Length of the queue is %d\n",len);

                }break;

            }
        }
    }

    return 0;
}
