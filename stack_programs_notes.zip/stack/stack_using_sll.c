#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node *next;
};
struct Node *top =NULL;
void push(int val)
{
    struct Node *newnode = (struct Node*)malloc(sizeof(struct Node*));
    if(newnode==NULL)
        printf("no memory");
    else{
        if(top==NULL)
        {
            newnode->data = val;
            newnode->next = NULL;
            top = newnode;
        }
        else{
            newnode->data = val;
            newnode->next = top;
            top = newnode;
        }
    }
}
void display()
{
    if(top==NULL)
        printf("Stack is empty");
    else{
        struct Node *temp =top;
        while(temp!=NULL)
        {
            printf("%d\n",temp->data);
            temp = temp ->next;
        }
    }
}
void pop()
{
    if(top==NULL)
        printf("Stack is empty");
    else{
            struct Node *temp = top;
        if(top->next==NULL)
        {
            top=NULL;
            free(temp);
        }
        else{
            top = top->next;
            free(temp);
        }
    }

}
int main()
{
     printf("1.push() 2.pop() 3.display() 4.peek() 5.is_empty() 6.is_full() -1.exit");
    int choice;
    while(1){
        scanf("%d",&choice);
        if(choice==-1)
         break;
        else{
            switch(choice)
            {
                case 1:{
                    int ele;
                    scanf("%d",&ele);
                    push(ele);
                }break;
                case 2:pop();break;
                case 3:display();break;
            }
         }


    }
}
