#include<stdio.h>
#define size 100
int stack[size];
int top=-1;
void push(int val)
{
    if(top>=size-1)
        printf("Stack is overflow");
    else
    {
        top++;
        stack[top] = val;
    }
}
void display()
{
    if(top==-1)
        printf("Stack is underflow");
    else
    {
        int itr;
        for(itr=top;itr>=0;itr--)
            printf("%d\n",stack[itr]);
    }
}
void pop()
{
    if(top==-1)
        printf("Underflow");
    else
    {
        top--;
    }
}
int peek()
{
    if(top==-1)
        return -1;
    else
        return stack[top];
}
int main()
{
    printf("1.push() 2.pop() 3.display() 4.peek() 5.is_empty() 6.is_full() -1.exit");
    int choice;
    while(1){
        scanf("%d",&choice);
        if(choice==-1)
            break;
        else
        {
            switch(choice)
            {
                case 1:{
                    int ele;
                    scanf("%d",&ele);
                    push(ele);
                }break;
                case 2:pop();break;
                case 3:display();break;
                case 4:{int val =peek();
                        if(val==-1)
                            printf("no top element\n");
                        else
                        printf("top is : %d\n",val);}break;
            }
        }
    }

    return 0;
}
