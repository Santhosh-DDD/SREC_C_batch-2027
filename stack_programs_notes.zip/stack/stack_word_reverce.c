#include<stdio.h>
#define size 100
char stack[size];
int top=-1;
void push(char ch)
{
    if(top>=size-1)
        printf("overflow");
    else
        stack[++top] = ch;
}
void display()
{
    if(top==-1)
        printf("Underflow");
    else
    {
        int itr;
        for(itr=top;itr>=0;itr--)
            printf("%c",stack[itr]);
    }
}
int main()
{
    char str[100];
    scanf("%[^\n]",str);
    int itr;
    for(itr=0;str[itr];itr++)
    {
        push(str[itr]);
    }
    display();

}
