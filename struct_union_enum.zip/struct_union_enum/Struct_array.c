#include<stdio.h>
typedef struct
{
   char name[20];
   int jersey;
   char native[20];
   float avg;
}team;
int main()
{
    team obj;
    obj.jersey=18;
    printf("%d",obj.jersey);


    return 0;
}
