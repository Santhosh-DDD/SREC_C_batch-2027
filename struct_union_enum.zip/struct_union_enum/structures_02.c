#include<stdio.h>
#include<string.h>
struct student
{
    char name[20];
    int marks[5];
    float avg;
};
int main()
{
    struct student stud;
    //input for name
    char name[20];
    scanf("%s",name);
    strcpy(stud.name , name);

   int itr,sum=0;
    for(itr=0;itr<5;itr+=1)
    {
        scanf("%d",&stud.marks[itr]);
        sum+=stud.marks[itr];
    }
    //printf("%d",sum);

    float average = (float)sum/5;
    stud.avg = average;


    //print name
    printf("Name is %s\n",stud.name);

    //printf marks
    for(itr=0;itr<5;itr+=1)
        printf("%d ",stud.marks[itr]);

    printf("\n");

    //print average
    printf("Average mark is %.2f",stud.avg);



    return 0;
}
