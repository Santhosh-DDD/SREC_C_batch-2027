#include<stdio.h>
#include<string.h>
struct student
{
    int roll_no;     // 4 4 4 4 4 4 4
    char name[20];
    float cgpa;
};
int main() // ref var or object
{
   struct student stud;
   struct student *s = &stud;
  // printf("%d",sizeof(stud)); 4+20+4 =28
  int num;
  char name[20];
  float cgpa;
  // for roll number
  scanf("%d",&num);
  s->roll_no = num;


  //for student name
  scanf("%s",name);
  strcpy(s->name,name);


  //for cgpa
  scanf("%f",&cgpa);
  s->cgpa = cgpa;

  printf("Roll number is :%d\n",stud.roll_no);
  printf("Name is :%s\n",stud.name);
  printf("Cgpa is %.2f",stud.cgpa);


 return 0;
}
