#include<stdio.h>
enum week_days
{
    monday,    //monday=10 , monday =3.14 X monday = "string" X
    tuesday,
    wednesday,
    thursday,
    friday,
    saturday,
    sunday
};
int main()
{
    enum week_days today = friday;
    printf("%d",today);


    return 0;
}
