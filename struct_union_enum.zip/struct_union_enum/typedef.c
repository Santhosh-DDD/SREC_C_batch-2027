#include<stdio.h>
/*struct student
{
    int roll_no;
    char name[20];
    float cgpa;
};
int main()
{
    struct student stud;

    stud.roll_no =10;
    printf("%d",stud.roll_no);

    return 0;
}*/

typedef struct
{
    int roll_no;
    char name[20];
    float cgpa;
}stud;
int main()
{
    stud s1;
    s1.roll_no=10;
    printf("%d",s1.roll_no);
    return 0;
}
