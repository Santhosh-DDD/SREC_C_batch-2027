#include<stdio.h>
#include<string.h>
struct student
{
    int roll_no;
    char name[20];
    float cgpa;
};
int main()
{
    struct student stud[3];

    //read the input for 3 students
    int itr;
    int roll_no;
    char name[20];
    float f;
    for(itr=0;itr<3;itr+=1)
    {
       //read roll_no
       scanf("%d",&roll_no);
       stud[itr].roll_no = roll_no;
       //read name
       scanf("%s",name);
       strcpy(stud[itr].name,name);
       //read cgpa
       scanf("%f",&f);
       stud[itr].cgpa = f;
    }

    //write 3 students data
    for(itr=0;itr<3;itr+=1)
    {
      printf("%d th student's data :\n",itr+1);
      printf("Roll Number = %d\n",stud[itr].roll_no);
      printf("Name = %s\n",stud[itr].name);
      printf("Cgpa = %.2f\n",stud[itr].cgpa);
    }



    return 0;
}
