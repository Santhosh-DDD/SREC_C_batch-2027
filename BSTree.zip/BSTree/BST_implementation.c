#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int data;
    struct Node *left;
    struct Node *right;
};
int min_element(struct Node *);
struct Node *root = NULL;
struct Node* create_Node(int val)
{
    struct Node *newnode = (struct Node*)malloc(sizeof(struct Node));
    if(newnode==NULL)
        return NULL;
    newnode->data = val;
    newnode->left =  NULL;
    newnode->right = NULL;
    return newnode;
}
struct Node* insertion(struct Node* node , int ele)
{
    if(node==NULL)
        return create_Node(ele);

    if(node->data < ele)
       node->right = insertion(node->right , ele);
    else if(node->data > ele)
        node->left = insertion(node->left,ele);

    return node;
}
void inorder(struct Node *node)
{
    if(node!=NULL)
    {
        inorder(node->left);
        printf("%d ->",node->data);
        inorder(node->right);
    }
}

struct Node* search(struct Node *node , int key)
{
    if(node==NULL || node->data == key)
         return node;

    if(node->data < key)
         search(node->right , key);
    else
        search(node->left , key );
}
struct Node* delete_node(struct Node* node , int key) //6 9 13 18
{
    if(node==NULL)
        return NULL;
    if(node->data < key)
        node->right = delete_node(node->right,key);
    else if(node->data > key)
        node->left = delete_node(node->left , key);
    else
    {
        //case 1 ,2 -- with one child , 0 child
        if(node->left==NULL)
        {
           struct Node* temp = node->right;
           free(node);
           return temp;
        }
        if(node->right==NULL)
        {
            struct Node *temp = node->left;
            free(node);
            return temp;
        }

        //case 3 node with 2 childs
        int min = min_element(node->right);
        node->data = min;
        node->right=delete_node(node->right,min);
    }
    return node;
}

int min_element(struct Node* node)
{
    if(node!=NULL)
     {
          struct Node *temp = node;
          while(temp->left!=NULL)
              temp = temp->left;
            return temp->data;
    }


}
int main()
{
    root = create_Node(100); //
    int ele;
    while(1)
    {
        scanf("%d",&ele);
        if(ele==-1)
            break;
        insertion(root,ele);
    }

    inorder(root);

    /* if(search(root,1000)==NULL)
       printf("No ele");
     else
        printf("Found");
        */
        ele = 100;
    delete_node(root,ele);
     inorder(root);


    return 0;
}
