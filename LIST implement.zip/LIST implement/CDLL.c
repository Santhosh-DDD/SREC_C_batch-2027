#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node *next;
    struct Node *prev;
};
struct Node *head=NULL;
void end_insertion(int val)
{
    struct Node *newnode = (struct Node*)malloc(sizeof(struct Node*));
    if(newnode==NULL)
        printf("No memory");
    else
    {
        if(head==NULL)
        {
            newnode->data =val;
            newnode->next=newnode;
            newnode->prev = newnode;
            head = newnode;
        }
        else
        {
            struct Node *temp=head;
            while(temp->next!=head)
            {
                temp = temp->next;
            }
            newnode->data = val;
            newnode->prev = temp;
            newnode->next = temp->next;
            temp ->next = newnode;
        }
    }
}
void display_forward()
{
    if(head==NULL)
        printf("Lis is empty");
    else
    {
        struct Node *temp =head;
        do
        {
            printf("%d ->",temp->data);
            temp=temp->next;
        }while(temp!=head);
    }
}
int main()
{
    int ele;
    while(1)
    {
        scanf("%d",&ele);
        if(ele==-1)
            break;
        end_insertion(ele);
    }
    display_forward();
}
