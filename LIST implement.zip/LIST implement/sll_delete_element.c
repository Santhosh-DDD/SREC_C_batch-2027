#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node *next;
};
struct Node *head=NULL;
void end_insertion(int val)
{
   struct Node *newnode = (struct Node *)malloc(sizeof(struct Node *));
   if(newnode==NULL)
      printf("No memory");
   else
   {
       if(head==NULL)
       {
           newnode->data = val;
           newnode->next = NULL;
           head = newnode;
       }
       else
       {
           struct Node *temp = head;
           while(temp->next!=NULL)
           {
               temp = temp->next;
           }
           newnode->data = val;
           temp->next=newnode;
           newnode->next = NULL;
       }
   }
}
void begin_delete(int val)
{
    if(head==NULL)
        printf("list is empty");
    else if(head->next==NULL)
    {
        struct Node *temp = head;
        head = NULL;
        free(temp);
    }
    else
    {
        struct Node *temp = head;
        head = head->next;
        free(temp);
    }
}
void delete_element(int del)
{
    if(head==NULL)
    {
        printf("List is empty");
    }
    else
    {
        if(head->data == del)
            begin_delete(del);
        else
        {
            struct Node *temp = head , *temp1;
            while(temp->next->next!=NULL)
            {
                if(temp->next->data == del)
                    break;
                temp = temp->next;
            }
            temp1 = temp ->next;
            temp ->next = temp1->next;
            free(temp1);
        }
    }
}
int length()
{
    if(head==NULL)
        return 0;
    else if(head->next==NULL)
        return 1;

    struct Node *temp =head;
    int count=0;
    while(temp!=NULL)
    {
        count++;
        temp = temp->next;
    }
    return count;
}
void bubble_sort(int len)
{
    if(head==NULL)
        printf("Not posible");
    else if(head->next==NULL)
        printf("Only one element");
    else
    {
        int pass,third;
        struct Node *temp;
        for(pass=1;pass<=len-1;pass+=1)
        {
            temp = head;
            while(temp->next!=NULL)
            {
                if(temp -> data > temp->next->data)
                {
                    third = temp->data;
                    temp->data = temp->next->data;
                    temp->next->data = third;
                }
                temp = temp->next;
            }
        }
    }
}
void display()
{
    if(head==NULL)
        printf("List is empty");
    else
    {
        struct Node *temp =head;
        while(temp!=NULL)
        {
            printf("%d -> ",temp->data);
            temp = temp->next;
        }

    }
}
int main()
{
    //list creation  -1
    int ele;
    while(1)
    {
        scanf("%d",&ele);
        if(ele==-1)
            break;
        end_insertion(ele);
    }
    display();

   /* int del;
    scanf("%d",&del);
    delete_element(del);
    printf("After the deletion \n");
    display();*/
    int len = length();
    bubble_sort(len);
    printf("After sorting :\n");
    display();

    return 0;
}
