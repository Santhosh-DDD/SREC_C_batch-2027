#include<stdio.h>
#include<stdlib.h>
//CSLL
struct Node
{
    int data;
    struct Node *next;
};
  struct Node *head = NULL;
void end_insertion(int val)
{
    struct Node *newnode = (struct Node*)malloc(sizeof(struct Node*));
    if(newnode==NULL)
        printf("No memory");
    else
    {
        if(head==NULL){
        newnode -> data =val;
        newnode-> next = newnode;
        head = newnode;
        }
        else
        {
            struct Node *temp = head;
            while(temp->next!=head)
                temp= temp->next;

            newnode->data =val;
            newnode->next=head;
            temp->next=newnode;
        }
    }
}
void display()
{
    if(head==NULL)
        printf("List is empty");
    else
    {
        struct Node *temp = head;
        do
        {
            printf("%d -> ",temp->data);
            temp = temp -> next;
        }while(temp!=head);
    }
}
void delete_element(int del)
{
   if(head==NULL)
        printf("List is empty");
   else if(head->next==head)
   {
       if(head->data == del)
       {
           struct Node *temp = head;
           head=NULL;
           free(temp);
       }
       else
       {
           printf("Cannot delete");
       }
   }
   else
   {
       struct Node *temp =head;
       if(head->data==del)
       {
           while(temp->next!=head)
           {
               temp=temp->next;
           }
           struct Node *temp1 = head;
           head = head ->next;
           temp->next=head;
       }
       else
       {
           do{
            if(temp->next->data == del)
                break;
            temp=temp->next;
           }while(temp!=head);
           if(temp==head)
           {
              printf("cannot delete");
           }
           else
           {
               struct Node *temp1=temp->next;
               temp->next=temp1->next;
               free(temp1);
           }

       }
   }
}
int main()
{
    int ele;
    while(1)
    {
        scanf("%d",&ele);
        if(ele==-1)
            break;
        end_insertion(ele);
    }

     display();
     int del;
     scanf("%d",&del);
     delete_element(del);
     display();

    return 0;
}
