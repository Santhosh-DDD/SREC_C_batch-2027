#include<stdio.h>
#include<stdlib.h>
struct Node
{
    struct Node *prev;
    int data;
    struct Node *next;
};
struct Node *head=NULL;
void end_insertion(int val)
{
    struct Node *newnode = (struct Node *)malloc(sizeof(struct  Node *));
    if(newnode==NULL)
        printf("No memory");
    else
    {
        if(head==NULL)
        {
            newnode->data = val;
            newnode -> next= NULL;
            newnode -> prev=NULL;
            head= newnode;
        }
        else
        {
            struct Node *temp =head;
            while(temp->next!=NULL)
                temp = temp->next;

            newnode->data = val;
            newnode->prev = temp;
            temp -> next =newnode;
            newnode->next=NULL;
        }
    }
}
void display_forward()
{
    if(head==NULL)
        printf("List is empty");
    else if(head->next==NULL)
    {
        printf("%d",head->data);
    }
    else
    {
        struct Node* temp =head;
        while(temp!=NULL)
        {
            printf("%d -> ",temp->data);
            temp = temp->next;
        }
    }
}
void display_backward()
{
    if(head==NULL)
        printf("List is empty");
    else
    {
        struct Node* temp = head;
        while(temp->next!=NULL)
        {
            temp = temp->next;
        }

        while(temp!=NULL)
        {
            printf("%d ->",temp->data);
            temp = temp->prev;
        }

    }
}

void delete_position(int pos)
{
    if(head==NULL)
    {
        printf("List is empty");
    }
    else if(head->next==NULL)
    {
        if(pos==1)
        {
            struct Node *temp =head;
            head=NULL;
            free(temp);
        }
        else
        {
            printf("Cannot delete");
        }
    }
    else
    {
        struct Node *temp =head;
        if(pos==1)
        {
            head = head->next;
            head->prev =NULL;
            free(temp);
        }
        else
        {
            int itr;
            for(itr=1;itr<=pos-1;itr+=1)
            {
                if(temp->next==NULL)
                    break;
                temp = temp->next;
            }
            if(itr<=pos-1)
            {
                printf("Cannot delete");
            }
            else
            {
                if(temp->next==NULL)
                {
                    temp->prev->next=NULL;
                    free(temp);
                }
                else{
                temp->prev->next = temp->next;
                temp->next->prev = temp->prev;
                free(temp);
                }
            }

        }

    }

}
int main()
{
    int ele;
    while(1)
    {
        scanf("%d",&ele);
        if(ele==-1)
            break;
        end_insertion(ele);
    }
    display_forward();
   /* printf("forward list elements :\n");
     display_forward();
     printf("\n");
     printf("Reverse list elements\n");
     display_backward();*/

     int pos ;
     scanf("%d",&pos);
     delete_position(pos);
     printf("After the deletion\n");
     display_forward();

    return 0;
}
