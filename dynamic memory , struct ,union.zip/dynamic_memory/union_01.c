#include<stdio.h>
#include<string.h>
union college
{
    int code;
    char name[30];
    float percentage;

};
int main()
{
    union college clg;
    clg.code = 4115;
    printf("code is %d\n",clg.code);
    strcpy(clg.name,"Sri ramakrishna");
    printf("Name is %s\n",clg.name);
    clg.percentage = 94.38;
    printf("placement percentage %.2f",clg.percentage);


    return 0;
}
