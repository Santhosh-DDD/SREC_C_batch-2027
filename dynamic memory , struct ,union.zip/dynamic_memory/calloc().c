#include<stdio.h>
#include<stdlib.h>
int main()
{
    int num=5;
    int *ptr;
    ptr =(int *) calloc(sizeof(int),5);

    int itr;
    printf("created memories are : \n");
    for(itr=0;itr<num;itr+=1)
        printf("%p ",ptr+itr);

    printf("\nintial valus of malloc \n");
     for(itr=0;itr<num;itr+=1)
        printf("%d ",*(ptr+itr));

     for(itr=0;itr<num;itr+=1)
        *(ptr + itr) = itr+1;

     printf("\nour stored values are \n");
     for(itr=0;itr<num;itr+=1)
        printf("%d ",*(ptr+itr));


}

