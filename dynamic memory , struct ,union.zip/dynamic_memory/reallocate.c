#include<stdio.h>
#include<stdlib.h>
int main()
{
    int num=7;
    int* ptr;
    ptr = (int*)malloc(sizeof(int)*num);
    if(ptr==NULL)
        printf("Memory not allocated");
    else
    {
        int itr;
         for(itr=0;itr<num;itr+=1) //1
            scanf("%d",ptr+itr);
         printf("\n");
         for(itr=0;itr<num;itr+=1)
            printf("%d ",&ptr[itr]);
         printf("\n");
         free(ptr);
         num=10;
         ptr = (int*)realloc(ptr,sizeof(int)*num);
          for(itr=0;itr<num;itr+=1) //1
            printf("%d ",ptr+itr);
        for(itr=0;itr<num;itr+=1)
            printf("%d ",ptr[itr]);

    }

}
