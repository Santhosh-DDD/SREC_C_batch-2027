#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
struct Node
{
    int vertex;
    struct Node *next;
};
struct graph
{
    int vertices;
    struct Node **adjlist;
};

struct queue{

int element[100];
int front;
int rear;
};


struct Node *create_node(int v)
{
    struct Node *newnode = (struct Node*)malloc(sizeof(struct Node));
    newnode -> vertex =v;
    newnode -> next =NULL;
    return newnode;
}

struct graph* create_graph(int num_vertices)
{
    struct graph *g =(struct graph *)malloc(sizeof(struct graph));
    g->vertices = num_vertices;
    g->adjlist =(struct Node **)malloc(num_vertices*sizeof(struct Node*));

    for(int itr=0;itr<num_vertices;itr+=1)
    {
        g->adjlist[itr] = NULL;
    }

    return g;
}
void addedge(struct graph *g , int s , int d) //0 --> 1
{
    struct Node *newnode = create_node(d);
    // destination added into source's adj list
    newnode->next = g->adjlist[s];  //newnode->next=head;
    g->adjlist[s] = newnode;        //head=nenwode

    //source added into destination's adj list
    newnode = create_node(s);
    newnode->next = g->adjlist[d];
    g->adjlist[d] = newnode;
}
void print_adjlists(struct graph *g , int src)
{
    int itr;
    for(itr=0;itr<g->vertices;itr+=1)
    {
        struct Node *temp = g->adjlist[itr];
        printf("Vertex of %d : ",itr);
        while(temp!=NULL)
        {
            printf(" %d -> ",temp->vertex);
            temp = temp->next;
        }
        printf("\n");
    }
}

bool isempty(struct queue *q)
{
    return q->rear==-1 || q->front > q->rear;
}

struct queue* create_queue()
{
    struct queue *q =(struct queue *)malloc(sizeof(struct queue));
    q->front=-1;
    q->rear =-1;
    return q;
}
void enqueue(struct queue* q , int v)
{
    if(q->rear>=99)
        return;
    else{
        if(q->front==-1 || q->rear==-1)
        {
            q->front++;
            q->rear++;
            q->element[q->rear] = v;
        }
        else{
            q->rear++;
            q->element[q->rear] = v;
        }

    }

}
int dequeue(struct queue *q)
{
    int ver;
    if(q->rear==-1)
        return -1;
    if(q->front == q->rear)
    {
        ver = q->element[q->front];
        q->front = -1;
        q->rear = -1;

    }
    else{
        ver = q->element[q->front];
        q->front++;
    }
        return ver;

}
void BFS(struct graph *g , int s)
{
    int* visited = (int*)calloc(g->vertices , sizeof(int));
    struct queue *q = create_queue();
    visited[s] = 1;
    enqueue(q,s);

    while(!isempty(q))
    {
       int c_ver = dequeue(q);
       printf("%d -> ",c_ver);

       struct Node *temp = g->adjlist[c_ver]; // 0 -- 4 ->1
       while(temp!=NULL)
       {
           int adj = temp->vertex;
           if(!visited[adj]) // 0 1
           {
               visited[adj]=1;
               enqueue(q,adj);
           }
           temp = temp ->next;
       }
    }
    free(visited);
}
int main()
{
    int num_vertices=5;

    struct graph *g = create_graph(num_vertices); //head=NULL

    addedge(g,0,1);
    addedge(g,0,4);
    addedge(g,1,2);
    addedge(g,1,3);
    addedge(g,1,4);
    addedge(g,2,3);
    addedge(g,3,4);

   print_adjlists(g,0);
   printf("\n");
  BFS(g,0);

    return 0;
}

